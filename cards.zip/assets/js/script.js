function myFunction() {
    var copyText = document.getElementById('myinput');
    var message = document.getElementById('copyMessage');

    // Regular expression to check if the text contains a URL
    var urlPattern = /(https?:\/\/[^\s]+)/g;

    if (urlPattern.test(copyText.value)) {
        copyText.select();
        copyText.setSelectionRange(0, 9999); // For mobile devices

        navigator.clipboard.writeText(copyText.value).then(function () {
            // Show the success message
            message.textContent = "Link copied to clipboard!";
            message.style.color = 'green';
            message.style.display = 'block';

            // Hide the message after 2 seconds
            setTimeout(function () {
                message.style.display = 'none';
            }, 2000);
        }).catch(function (err) {
            console.error('Failed to copy text: ', err);
        });
    } else {
        // Show the error message
        message.textContent = "No link found to copy.";
        message.style.color = 'red';
        message.style.display = 'block';

        // Hide the message after 2 seconds
        setTimeout(function () {
            message.style.display = 'none';
        }, 2000);
    }
}


// notifications
const notContainer = document.getElementById("notwrap");

const notfts = notContainer.getElementsByClassName("cd-ppl");

const notftsArray = Array.from(notfts);

notftsArray.forEach(btn => {
    btn.addEventListener("click", () => {
        const current = document.querySelector(".actives");
        if (current) {
            current.classList.remove("actives");
        }
        btn.classList.add("actives");
    });
});